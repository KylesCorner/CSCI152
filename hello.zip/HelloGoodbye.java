/*
 * Kyle Krstulich
 * 8/28/23
 * CSCI151
 * HelloGoodbye.java
 */
public class HelloGoodbye{
    public static void main(String[] args) {
        String name_1 = args[0];
        String name_2 = args[1];
        System.out.println("Hello " + name_1 + " and " + name_2 + ".");
        System.out.println("Goodbye " + name_2 + " and " + name_1 + ".");
    }
}