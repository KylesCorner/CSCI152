
/*
 * Kyle Krstulich
 * 8/28/23
 * CSCI151
 * HelloWorld.java
 */
public class HelloWorld{
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}